import { Component, OnInit } from '@angular/core';
import { ApplicationAdd } from '../model/application-add';
import { Options } from 'ng5-slider';

@Component({
  selector: 'app-life',
  templateUrl: './life.component.html',
  styleUrls: ['./life.component.css']
})
export class LifeComponent implements OnInit {
  value: number = 123;
  options: Options = {
    floor: 1000000,
    ceil:  2000000
  };


applications: ApplicationAdd[]=[
  {
    id:1, name:1
  },
  {
    id:2, name:2
  },
  {
   
    id:3, name:3
  },
  {
    id:4, name:4
  }
];
  constructor() { }

  ngOnInit() {
  }

}
