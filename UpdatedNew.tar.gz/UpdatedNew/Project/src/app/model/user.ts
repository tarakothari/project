export class User {
    user_id:number;
    name: string;
    email:  string;
    password:  string;
    city:  string;
    state:  string;
    address:  string;
    dob: Date;
    mob_no: number;
    role_id: number;
    }