import { ApplicationAdd } from './application-add';

describe('ApplicationAdd', () => {
  it('should create an instance', () => {
    expect(new ApplicationAdd()).toBeTruthy();
  });
});
