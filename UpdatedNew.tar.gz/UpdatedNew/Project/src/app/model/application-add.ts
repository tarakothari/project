export class ApplicationAdd {
    id:number;
    name:number;
}
