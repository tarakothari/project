import { Component, OnInit } from '@angular/core';
import { User } from '../model/user';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
user:User;
  constructor(private route:ActivatedRoute, private router:Router,private userService:UserService) {
    this.user=new User();
  }
      
          
  // Function to check Whether both passwords 
  // is same or not. 
 
 onSubmit(){
   this.userService.save(this.user).subscribe();
 }

  
}
