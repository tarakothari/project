import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BodyComponent } from './body/body.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { PoliciesComponent } from './policies/policies.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { Ng5SliderModule } from 'ng5-slider';

import { ReactiveFormsModule, FormsModule} from '@angular/forms';
import{FormGroup,FormControl,Validators}from '@angular/forms';
import { AdminComponent } from './admin/admin.component';
import { LifeComponent } from './life/life.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    FooterComponent,
    BodyComponent,
    RegisterComponent,
    HomeComponent,
    PoliciesComponent,
    AboutusComponent,
    AdminComponent,
    LifeComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    Ng5SliderModule ,


  

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

