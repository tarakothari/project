import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
// export class LoginComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
export class LoginComponent implements OnInit {
  submitUser(form){
    console.log(form.value);
    alert("The form was submitted");
    form.reset();
  }
  ngOnInit() {
       }
}